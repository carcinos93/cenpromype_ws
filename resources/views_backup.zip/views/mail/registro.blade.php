
<div class="container" style="margin: 1rem 0 0 1rem;">
 <p style="font-family: Arial, Helvetica, sans-serif;">Bienvenido {{ $nombre_completo }} a cenpromype</p>
<p style="font-family: Arial, Helvetica, sans-serif;"> Para completar el registro clic en el enlace o copiarlo y pegarlo en el navegador web.</p>    
<p style="font-family: Arial, Helvetica, sans-serif;"> <a href="{{ $url }}">{{ $url }}</a>  </p>
</div>
