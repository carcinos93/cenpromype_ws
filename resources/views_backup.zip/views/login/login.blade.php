@extends('layout.master')
@section('initialScript')
    <script>
        window['baseUrl'] = "{{ url('/') . '/' }}";
    </script>
@endsection
@section('content')
<div id="app"></div>
@endsection

