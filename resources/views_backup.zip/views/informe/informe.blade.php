<style>

    .btn-3 {  background-color: #f3f3f4; color: #135fa7 !important; border: 1px solid #135fa7; }

    .p-grid .pi { font-size: 1.5rem; }
    .position-relative { position: relative; }
    .p-hidden { display: none; }
    .contendor-iframe {width: 100%;}
    #contenedor-html[src="#"] { display: none }
    .pointer-click .pi { cursor: pointer }
</style>
<input type="hidden" id="sectorId" value=""  />

<div class="elementor-container p-shadow-7" id="listaInformes">
    <div class="p-grid p-jc-center p-mt-3">
        <div class="p-col-12">
            <div class="p-grid p-jc-start">
                <div class="p-col-8 p-md-6">
                    <div class="btn-dinamico btn-2 p-text-center" style="text-transform: capitalize">
                        {{  $servicio['NOMBRE_SERVICIO']  }}
                    </div>
                </div>
            </div>
        </div>
        <div class="col no-gutter p-col-12">
            <div class="p-grid p-ml-5">
                @foreach( $informes as $informe )
                    <div data-url="{{ route('vista.documento', [ 'iddocumento' => $informe['CODIGO_DOCUMENTO'] ] ) }}" class="p-col-11 p-md-8 btn-dinamico btn-3 documento-visor" >
                        <b> {{ $informe['DESCRIPCION_DOCUMENTO']  }}</b>
                    </div>
                    <div class="p-col-12" style="padding-bottom: 0.2rem"></div>
                @endforeach
            </div>
        </div>
    </div>
</div>

<div style="z-index: 9999" class="p-hidden bg-white contendor-iframe">
    <div class="p-d-block p-mt-5">
        <div class="p-grid p-jc-end pointer-click">
            <div class="p-col-6 p-md-2">
                <div class="p-grid">
                    <div class="p-col">
                        <i class="pi pi-file-pdf"></i>
                    </div>
                    <div class="p-col">
                        <i class="pi pi-print "></i>
                    </div>
                    <div class="p-col">
                        <i class="pi pi-envelope"></i>
                    </div>
                    <div class="p-col">
                        <i class="pi pi-arrow-circle-left ejecutar-evento" data-evento="regresarInforme" ></i>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <iframe frameborder="0" style="overflow:hidden !important;height:100%;width:100%; " height="100%" width="100%" src="{{ route('vista.ok') }}" id="contenedor-html"></iframe>
</div>
<script>
    var mostrarIframe = false;
    $(function () {
   /** si no existe el elemento contenedor del iframe entonces se agrega y se le añade una clase
        * esto se realiza ya que al cargar de nuevos los productos vuelve a crear el contenedor del iframe
        **/
        if (! $(".ast-container .contendor-iframe.principal").length ) {
            $(".contendor-iframe").addClass("principal"); //se añade una clase
            $(".ast-container").append( $(".contendor-iframe.principal") ); //se agrega el contenedor
        }

        $(".documento-visor").each(function (e) {
            const elem = $(this);
            elem.on('click', function () {
                const url = elem.attr("data-url");
                cargarDocumento(url);
            });
        });

        $(".contendor-iframe.principal .ejecutar-evento").each(function (e) {
            const elem = $(this);
            elem.on('click', function () {
                const evento =  elem.attr("data-evento");
                if (typeof window[evento] == "function") {
                    window[evento]();
               }
            });
        });
        /**
         * este evento se ejecuta cuando se hace un cambio en la propiedad src del iframe
         * */
        $(".contendor-iframe.principal iframe").on('load',function (e) {
            var $this = this;
            setTimeout(function () {

                if (mostrarIframe) {
                    //$("#content").addClass('position-relative');
                    $(".contendor-iframe.principal").removeClass("p-hidden");
                    $("#primary").addClass("p-hidden");
                    $("#listaInformes").addClass("p-hidden");
                } else {
                    $(".contendor-iframe.principal").addClass("p-hidden");
                    //$("#content").removeClass('position-relative');
                    $("#listaInformes").removeClass("p-hidden");
                    $("#primary").removeClass("p-hidden");
                }

                $($this).height($($this).contents().height());
                swal.close();
            }, 1200);
           //ajuste de altura
           
        });
     
    });
    function regresarInforme() {
        cargando('') //en el evento de load del iframe se realiza el cierre del evento cargando
        mostrarIframe = false;
        //"/~oqmdev/cenpromype_ws/vistas/ok"
        $("#contenedor-html").attr("src", "{{ route('vista.ok') }}"  );
    }
    function cargarDocumento( url ) {
        cargando('')
        mostrarIframe = true;
        $(".contendor-iframe.principal iframe").height("100%");
        ///~oqmdev/cenpromype_ws/vistas/documento/
        $("#contenedor-html").attr("src", url);


    }

</script>




